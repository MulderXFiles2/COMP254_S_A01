package com.matt;

//Matthew Ferrari 301357343

//Exercise 1
//
//In this exercise, you will use the DoublyLinkedList implementation of the textbook (week 2 lecture examples.
//Write a method for concatenating two doubly linked lists L and M, with header and trailer sentinel nodes,
//into a single list L′. Write a main method to test the new method. Hint: Connect the end of L into the
//beginning of M.

public class DoublyLinkedList <E>{

    private static class Node<E> {
        E element;
        Node<E> previous;
        Node<E> next;

        public Node (E ele, Node<E> prev, Node<E> nex){
            this.element = ele;
            this.previous = prev;
            this.next = nex;
        }

        public E getElement() {return element; }
        public Node<E> getPrevious() {return previous;}
        public Node<E> getNext() { return next; }
        public void setPrevious(Node<E> prev) {previous = prev; }
        public void setNext(Node<E> nex) {next = nex;}

    }

    private Node<E> header;
    private Node<E> trailer;
    private int size = 0;

    //This creates a new list, with 2 nodes, a header and a trailer, and links them together

    //Constructor
    public DoublyLinkedList(){
        header = new Node<>(null,null,null);
        trailer = new Node<E>(null, header,null);
        header.setNext(trailer);

    }

    //Add an element at the end of the list
    //The trailer will never hold an element, the element is stored in the 2nd last node, same for head,
    //both of those are called sentinel nodes.
    public void addLast(E element) {
        Node<E> last = trailer.getPrevious();
        Node<E> newNode = new Node<>(element, last, trailer);
        trailer.setPrevious(newNode);
        last.setNext(newNode);
        size++;
    }

    // To print out the doubly linked lists

    //Override the toString() method for this class to print out something useful.
    //String builder adds things onto the same object one piece at a time.
    //

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node<E> starting = header.getNext();
        while (starting != trailer) {
            sb.append(starting.getElement()).append(" ");
            starting = starting.getNext();
        }
        return sb.toString();
    }

    //This is Exercise 1, concatenating two doubly linked lists, L and M


    //Method
    public DoublyLinkedList<E> concatenateLists(DoublyLinkedList<E> xyz ) {
        DoublyLinkedList<E> newL = new DoublyLinkedList<>();

        //this reference here refers to the doubly linked list we are calling the method on.

        //in this case, when this method is called, it is called on L linked list. L.concatenateLists(M);
        //this method gets the elements and next references from that list, and copies them to the
        //new list. newL.addLast(startingNode.getElement());
        //then we attach M (what we passed in). startingNode = xyz.header.getNext();
        //Both lists are now one long list
        //
        Node<E> startingNode = this.header.getNext();
        while (startingNode != this.trailer) {
            newL.addLast(startingNode.getElement());
            startingNode = startingNode.getNext();

        }

        startingNode = xyz.header.getNext();
        while (startingNode != xyz.trailer) {
            newL.addLast(startingNode.getElement());
            startingNode = startingNode.getNext();

        }

        return newL;
    }

    public static void main(String[] args) {

        //Testing Code

        //L Doubly Linked list, ABC with header and trailer
        DoublyLinkedList<String> L = new DoublyLinkedList<>();
        L.addLast("A");
        L.addLast("B");
        L.addLast("C");

        // Same thing for M doubly linked list

        DoublyLinkedList<String> M = new DoublyLinkedList<>();
        M.addLast("4");
        M.addLast("5");
        M.addLast("6");

        //Show the lists

        System.out.println("Printing out L and M Doubly linked lists");
        System.out.print("List L: " + L);

        System.out.println();
        System.out.print("List M: " + M);
        System.out.println();

        DoublyLinkedList<String> newList = L.concatenateLists(M);

        System.out.println("Both Lists concatenated: " + newList);

    }

}

