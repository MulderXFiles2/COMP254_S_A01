package com.matt;

//Matthew Ferrari 301357343
//This Singly Linked List is from the power point slides

//Exercise 2
//
//In this exercise, you will add a method swapNodes to SinglyLinkedList class from week 2 lecture examples.
//This method should swap two nodes node1 and node2 (and not just their contents) given references only to
//node1 and node2. The new method should check if node1 and node2 are the same node, etc. Write the
//main method to test the swapNodes method. Hint: You may need to traverse the list.

public class SinglyLinkedList<E> {

    private static class Node<E> {
        private E element;
        private Node<E> next;

        public Node(E e, Node<E> n) {
            element = e;
            next = n;
        }

        public E getElement() { return element; }
        public Node<E> getNext() { return next; }
        public void setNext(Node<E> n) { next = n; }
    }

    private Node<E> head = null;
    private Node<E> tail = null;
    private int size = 0;

    //Constructor
    public SinglyLinkedList() { }

    public int size() { return size; }

    public boolean isEmpty() { return size == 0; }

    public E first() {
        if (isEmpty()) return null;
        return head.getElement();
    }

    public E last() {
        if (isEmpty()) return null;
        return tail.getElement();
    }

    //Add last node to singly linked list

    public Node<E> addLast(E e) {
        Node<E> newest = new Node<>(e, null);
        if (isEmpty()) {
            head = newest;
        } else {
            tail.setNext(newest);
        }
        tail = newest;
        size++;
        return newest;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        Node<E> current = head;

        while (current != null) {
            sb.append(current.getElement()).append(" ");
            current = current.getNext();
        }

        return sb.toString();
    }

    //If you had A, B, C, D, E in a singly linked list
    //For example, swap Node C and D

    public void swapNodes(Node<E> prev, Node<E> node1, Node<E> node2){
        if (node1 == node2){
            return;
        }

        node1.setNext(node2.getNext());

        node2.setNext(node1);

        if (prev != null) {
            prev.setNext(node2);
        } else {
            head = node2;
        }

    }

    public static void main(String[] args) {
        SinglyLinkedList<String> slist = new SinglyLinkedList<>();


        Node<String> nodeA = slist.addLast("A");
        Node<String> nodeB = slist.addLast("B");
        Node<String> nodeC = slist.addLast("C");
        Node<String> nodeD = slist.addLast("D");
        Node<String> nodeE = slist.addLast("E");

        System.out.println("Before swapping C and D node swap:");
        System.out.println(slist);


        slist.swapNodes(nodeB, nodeC, nodeD);

        System.out.println("After swapping C and D:");
        System.out.println(slist);
    }

}
