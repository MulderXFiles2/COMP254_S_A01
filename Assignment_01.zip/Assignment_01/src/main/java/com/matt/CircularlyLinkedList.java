package com.matt;

//Matthew Ferrari 301357343
//In this exercise you will add a clone() method to CircularlyLinkedList class from week 3 lecture examples.
//Write a main method to test the new method. Hint: See the implementation of clone method in SinglyLinkedList
//class, Make sure to properly link the new chain of nodes.

public class CircularlyLinkedList<E> {

    private Node<E> tail = null;
    private int size = 0;

    private static class Node<E> {
        private E element;
        private Node<E> next;

        public Node(E e, Node<E> n) {
            this.element = e;
            this.next = n;
        }

        public E getElement() { return element;}

        public Node<E> getNext(){ return next;}

        public void setNext(Node<E> n) { next = n;}
    }

    public void addfirst(E e) {
        if (this.size == 0) {
            this.tail = new Node(e, null);
            this.tail.setNext(this.tail);
        } else {
            Node<E> newest = new Node(e, this.tail.getNext());
            this.tail.setNext(newest);
        }
        ++this.size;
    }

    public String toString(){
        if (tail == null) return "Empty";

        StringBuilder sb = new StringBuilder();

        Node<E> starting = tail.getNext();

        for (int i = 0; i < size; i++) {
            sb.append(starting.getElement());
            sb.append(" ");
            starting = starting.getNext();
        }

        return sb.toString();
    }

    //The clone method for this circularly linked list
    //The clone should be a deep copy here, to create new objects but with the same contents.
    //A shallow copy only copies the original references, so the two lists would affect one another.
    //A deep copy is a separate object, so changing it doesn't affect the other one.


    public CircularlyLinkedList<E> clone() {
        CircularlyLinkedList<E> copiedList = new CircularlyLinkedList<>();

        if (this.tail == null) return copiedList;

        Node<E> currentNode = this.tail.getNext();

        Node<E> newNode = new Node<>(currentNode.getElement(), null);

        copiedList.tail = newNode;

        newNode.setNext(newNode);

        copiedList.size++;

        return copiedList;

    }

    public static void main(String[] args) {

        //Testing

        CircularlyLinkedList<String> clist = new CircularlyLinkedList<>();
        clist.addfirst("A");
        clist.addfirst("B");
        clist.addfirst("C");
        clist.addfirst("D");
        clist.addfirst("E");

        System.out.println("List Before Cloning");
        System.out.println(clist);

        CircularlyLinkedList<String> clonedList = clist.clone();

        System.out.println("Cloned List:");
        System.out.println(clonedList);







    }

}
